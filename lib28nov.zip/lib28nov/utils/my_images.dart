class MyImages {
  MyImages._();

  static const String bgImage = "assets/images/bgImage.png";
  static const String logo = "assets/images/logo.png";
  static const String logo1 = "assets/images/logo1.png";
  static const String splash = "assets/images/splash.png";
  static const String dummy = "assets/images/dummy.png";
  static const String gallery = "assets/images/gallery.png";
  static const String compLogo = "assets/images/compLogo.png";
  static const String invoice = "assets/images/invoice.png";
  static const String sent = "assets/images/sent.png";
  static const String dropdownIcon = "assets/images/dropdownIcon.png";
  static const String bottomIcon1 = "assets/images/bottomIcon1.png";
  static const String bottomIcon2 = "assets/images/bottomIcon2.png";
  static const String bottomIcon3 = "assets/images/bottomIcon3.png";
  static const String bottomIcon4 = "assets/images/bottomIcon4.png";
  static const String bottomIcon5 = "assets/images/bottomIcon5.png";
}
