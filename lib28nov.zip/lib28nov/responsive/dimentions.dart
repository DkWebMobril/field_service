const mobileWidth = 400;

const desktopWidth = 800;
