import 'package:flutter/material.dart';

class OTPDesktopScreen extends StatefulWidget {
  const OTPDesktopScreen({super.key});

  @override
  State<OTPDesktopScreen> createState() => _OTPDesktopScreenState();
}

class _OTPDesktopScreenState extends State<OTPDesktopScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}