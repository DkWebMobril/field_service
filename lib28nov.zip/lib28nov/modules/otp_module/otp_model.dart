import 'package:field_service/utils/viewModel.dart';

class OTPModel extends ViewModel{
  
}