
import 'package:field_service/utils/viewModel.dart';

class ProfileModel extends ViewModel{
  
}