import 'package:field_service/utils/viewModel.dart';

class StartUpSetModel extends ViewModel{

}