import 'package:flutter/material.dart';

class StatrtUpDesktopScreen extends StatefulWidget {
  const StatrtUpDesktopScreen({super.key});

  @override
  State<StatrtUpDesktopScreen> createState() => _StatrtUpDesktopScreenState();
}

class _StatrtUpDesktopScreenState extends State<StatrtUpDesktopScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}